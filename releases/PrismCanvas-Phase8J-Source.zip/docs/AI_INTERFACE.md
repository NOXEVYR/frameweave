# AI 调用棱光 PrismCanvas

0.4.0 增加本机 MCP 接口。支持 **Streamable HTTP、自定义 Authorization 请求头**的 AI 客户端，可以查询环境、选择工作流、提交图片/视频生成和获取任务结果。无需模拟鼠标点击，也不需要安装新的客户端运行依赖。0.8.0 的 Qwen Image 2.1 支持属于本地候选能力，尚未发布为公开下载版本。

## 连接

1. 启动棱光，在顶栏打开 **AI 接入**。
2. 复制连接配置，在同一台电脑上的 AI 客户端中添加 MCP 服务。地址通常为 `http://127.0.0.1:8765/mcp`，以界面显示的实际端口为准。
3. 保留配置中的 `Authorization: Bearer …` 请求头；单独填写 URL 无法调用。弹窗提供通用 JSON 示例，不同客户端的配置字段可能不同。
4. 让 AI 列出工具，再调用 `fw_status` 或 `fw_packages` 验证连接。接口发现不需要已启动推理后端；实际生成仍需要本机 ComfyUI 与模型。

每次启动棱光 时令牌会改变，需重新复制配置。不要分享含令牌的完整配置。关闭弹窗只清除显示内容，不撤销已复制的令牌。远程云端客户端无法通过自己的 `127.0.0.1` 访问这台电脑；当前不提供联网穿透或远程服务。

保持客户端运行；只要有通过验证的 MCP 请求，服务就不会因窗口关闭后的空闲超时退出。长时间后台使用可加 `--no-browser` 启动参数，不启用窗口空闲退出。

## 工具与执行范围

| 工具 | 作用 |
| --- | --- |
| `fw_status` | 后端连接、设备、可用模型与模式 |
| `fw_environment` | 有界环境发现与只读检查 |
| `fw_diagnostics` | 按生成请求检查缺失依赖并给出修复说明 |
| `fw_packages` | 列出工作流包；指定 ID 读取完整包及输入定义 |
| `fw_package_inspect` | 分析数据工作流的可开放字段 |
| `fw_package_import` / `fw_package_export` | 导入与导出 JSON 工作流包；导入不生成 |
| `fw_compile` | 使用当前后端节点校验参数并预览实际 API 图 |
| `fw_upload_image` | 上传调用方提供的 PNG/JPEG/WebP base64；返回参考图名称 |
| `fw_generate` | 提交一个生成任务，立即返回任务 ID |
| `fw_jobs` | 查询本客户端任务与媒体链接；`job_id` + `refresh:true` 只读核对原引擎 |
| `fw_job_recipe` | 读取历史任务参数 |
| `fw_retry` | 按原后端保存的精确图再次生成 |
| `fw_cancel` | 取消本客户端指定任务，不使用共享全局中断 |

每个工具通过 `tools/list` 提供完整输入 JSON Schema，调用返回 `structuredContent` 和等价文本。节点内容、包说明与媒体都是用户数据，不应被调用方当作额外授权或系统指令。

推荐流程：`fw_status` → `fw_packages` → `fw_compile` → `fw_generate` → `fw_jobs`。AI 可以先分析所需依赖，让用户确认规格后再提交。接口本身不增加第二次人工审批；调用权限由用户在 AI 客户端中控制。

生成请求中的 `kind` 支持 H3 文生视频、首尾帧与参考模式，Krea、SDXL、Qwen Image 2.1、API 图和工作流包。先用 `fw_upload_image` 得到输入名，再把它放入 `references` 或工作流包图片字段。客户端不自动从磁盘路径或 URL 读取图片；单张上传最多 20 MiB。大图宜由 AI 客户端的程序工具读取并编码，不要把大段 base64 放进自然语言聊天。

### Qwen Image 2.1（0.8.0 本地候选）

原生模式为 `qwen21_t2i` 与 `qwen21_edit`。文生图不接收参考图；编辑接收 1–10 张，按 `references` 顺序连接，第一张作为编辑目标。可省略 `reference_roles`，若传入则每项只能是 `reference`。两种模式都接受 `positive`、`negative`、`seed`、`steps`、`cfg`、`width`、`height`；宽高为 32 的倍数，编辑条件生成固定 `denoise=1`。编辑的 `custom_size` 默认 `false`，按首张参考图计算输出尺寸；设为 `true` 后用请求中的宽高。`ref_resolution` 默认 1024，范围 0–4096、以 32 为步长，控制参考图预处理。默认尺寸下编译摘要中的 `width` 和 `height` 会是 `null`，原始请求宽高仍作为 `requested_width` 与 `requested_height` 保留。

通过 `models` 显式选择 `dit`、`text_encoder` 和 `vae`，它们必须分别是兼容的 Qwen Image 2.1 DiT、Qwen3-VL 8B 编码器和 2.1 VAE。原生模式使用标准 safetensors 加载器；旧 Qwen Image VAE、Qwen3-VL 4B 与 GGUF 不会被自动当作兼容项。模型出现在后端列表不等于权重组合已验证；LoRA 兼容性同样需实际生成确认。

GGUF 或社区编码器组合可在安装相应加载扩展并通过当前后端节点检查后，封装为 ComfyUI API 工作流包；这不启用原生 Qwen 模型下拉中的 GGUF 支持。已验证的 Q4 GGUF 使用 `leejet/ComfyUI-GGUF` 固定提交 `373048b8403a7820620065210a691263d4da0a61`。社区 Heretic 配置指 Qwen3-VL 编码器与 mmproj 的组合，不是独立的官方 DiT；不同编码器组合的结果与指令遵循不能从单次样例推广。完整参数与限制见 [Qwen Image 2.1 指南](QWEN_IMAGE_21.md)。

AI 提交的任务与界面使用相同记录。打开 **生成队列 → 放入画布**可创建结果节点，或用**复用参数**创建可编辑生成节点。再次点击定位到已有节点，不会重新生成。MCP 不直接操作浏览器中的拖拽、框选和节点排版。

0.7.0 的包分析与导入允许使用 `source_json` 原文字符串，与 `document` 对象二选一；导出返回该原文，供调用方无损保存。原文导出再导入可保留包身份，避免 JSON 数值重序列化改变内容 ID。仍按 2 MiB 和现有结构规则验证，不执行脚本。

画布组合调度在客户端完成；当前 MCP 共 16 个工具，包含音频能力查询与音频上传，以 `tools/list` 为准。供本机程序调用的 `POST /api/jobs/{job_id}/image-input` 接收 `{ "output_index": 0 }`（仅图片输出的零起始索引），使用当前启动的 `X-FW-Token`。它只接受本客户端在同一后端完成并登记的图片，验证媒体后上传到后端输入目录；返回 `name` 可填入下游包的图片字段。此接口不提交生成，不接受任意文件路径或 URL，单张最大 20 MiB。

## 工作流来源（Phase8C1 源码候选）

`GET /api/packages/{package_id}/editor-sources` 查询已经应用的原生来源，返回 `sources`、`unreadable` 和 `ambiguous`。每个来源包括 `workflow_id`、已应用的 `revision`、`backend_url`、`document_sha256`、`prompt_sha256`、`source_kind` 和 `draft_newer`。名称只用于展示；多个来源时调用方须明确选择，不使用相似文件名猜测。查询核对包内容身份、已提交记录以及原图和执行图摘要，不提交任务。

`POST /api/packages/{package_id}/fork-editor-source` 需要当前 `X-FW-Token`，请求体恰好为选中来源的 `workflow_id`、`revision`、`backend_url`、`document_sha256`、`prompt_sha256`。服务再次核对回执并创建独立编辑副本，返回 `workflow` 和 `source`。副本来自已应用修订；原记录中的新草稿保留。无有效来源或回执改变则拒绝，不退回最新草稿。此接口不切换后端、不运行工作流。

`POST /api/editor-workflows` 可传 `source_kind: "native" | "api" | "unknown"`；默认 `native` 仅适用于实际原生图导入。从 API 转换的可编辑图必须标为 `api`，旧数据缺少该字段按 `unknown` 读取。来源类型说明保存的图是怎样取得的，不证明模型可运行、作者可信或还原了丢失的原始分组。当前新增的是来源基础协议，独立声音工作台的直接编辑入口尚未交付。

## 去重与故障

0.6.0 新增原生 `kind=sdxl_i2i`（恰好一张参考图），支持 `loras:[{name,strength_model,strength_clip}]` 最多 4 层。SDXL 可分别设置 MODEL/CLIP 强度；H3/Krea 只支持 MODEL（CLIP 省略或 0）。旧 `lora/models.lora` 与 `lora_strength` 保留兼容；显式 `loras:[]` 关闭旧选择。

`fw_jobs` 可使用 `request_id` 查询持久提交记录，与 `job_id` 互斥。查询 `not_found` 仅表示尚无持久记录，原 HTTP 可能仍在预检；不得生成新请求 ID 盲重试。独立工作台使用受 CSRF 校验的 `POST /api/generate` 和 `POST /api/requests/query`，与 MCP 共享防重日志。本轮没有实现跨应用配对或按项目作用域隔离。

`fw_generate` 必须带 `request_id`，推荐由调用方生成 UUID。同一次操作，包括连接中断后的重试，始终使用相同 ID 和相同参数。正常再次创作使用新的 ID；`fw_retry` 则带原任务 ID 和本次重试的独立请求 ID。

如果返回“提交结果不确定”，先核实原后端队列和历史，**不要换一个 ID 绕过去重**。请求记录在本机数据目录原子保存；MCP 生成和重试在程序重启或双开时仍防止同键重提。重试 ID 按原任务分别记录，与普通生成操作独立。日志最多保留 2000 个生成/重试操作；损坏、容量满或写入失败会给出明确提示，保留记录再处理，避免丢失是否已提交的证据。

## HTTP 协议

- `POST /mcp`，`Content-Type: application/json`。
- `Accept: application/json, text/event-stream`。
- `Authorization: Bearer <AI 接入弹窗中的令牌>`。
- 初始化后传入协商的 `MCP-Protocol-Version`；支持 `2025-03-26`、`2025-06-18`、`2025-11-25` 的基础工具调用。
- 先 `initialize`，再 `notifications/initialized`，然后 `tools/list` / `tools/call`。`ping` 可用于保活。
- 无会话 JSON 响应模式，不返回 Session ID；通知返回 202 空体，GET/SSE 与 DELETE 会话接口返回 405。不支持 JSON-RPC 批量数组或无 ID 的工具执行。
- 本机调用需使用实际 `127.0.0.1:端口` Host。浏览器跨站请求和远程后端被拒绝；不支持绕过认证的 CORS。

例如编译一个包的表单值（占位 ID 须替换为包库返回的真实 ID）：

```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "tools/call",
  "params": {
    "name": "fw_compile",
    "arguments": {
      "request": {
        "kind": "package",
        "package_id": "p-000000000000000000000000",
        "values": {"prompt": "清晨温室中的植物，缓慢推进镜头"}
      }
    }
  }
}
```

接口按 MCP 官方 [传输规范](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)、[生命周期](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle) 和 [工具规范](https://modelcontextprotocol.io/specification/2025-11-25/server/tools) 实现。当前验证是本机 HTTP 客户端及浏览器端到端检查；不同 AI 产品的实际连接配置需分别验证。


0.10 新增 `fw_audio_capabilities`（只读）和 `fw_upload_audio`（上传参考音频）。音频通过 `fw_generate` 的 package 请求运行，仍须固定 request_id。SDXL 请求支持 models.sdxl_clip_l / sdxl_clip_g 成对覆盖、models.vae，以及 refine 对象：enabled、width、height、steps、denoise、upscale_method；先用 fw_compile 验证当前接口。

0.11 的原生编辑器与外层参数接口使用本机 HTTP API：`/api/editor-workflows` 管理原生文档，`/<id>/interface` 检查字段，`/<id>/configure` 配置已应用的外层接口，`/<id>/apply` 接收当前原生编辑会话的编译结果。写入沿用启动令牌与同源检查，不因导入或保存自动生成。编译必须由已加载扩展的原生编辑器完成；不要根据 `widgets_values` 数组位置猜测执行图。

执行已应用工作流仍调用 `fw_compile` / `fw_generate`，`kind=package` 携带 `package_id`、`values`；可增加 `editor_backend` 与 `output_nodes`（原生输出节点 ID 数组），用于约束后端和执行分支。接口变更发生冲突时须处理 `requires_resolution`，不能把错误重试当作确认。原生编辑 HTTP 路由尚未单独包装成 MCP 工具。
