"""Black-box loopback HTTP tests; the mock backend never performs inference."""

import base64
import copy
import http.client
import json
import re
import socket
import tempfile
import threading
import time
import unittest
import urllib.parse
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from frameweave.server import MAX_JSON, App, make_server


PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jhXcAAAAASUVORK5CYII="
)
API_JOB = {"kind": "api", "prompt": {
    "1": {"class_type": "TestOutput", "inputs": {"text": "a quiet scene"}}
}}


class MockComfy:
    """Small independent implementation of the public endpoints needed here."""

    def __init__(self):
        self.info = {"TestOutput": {"input": {"required": {"text": ["STRING"]}},
                                    "output": [], "output_node": True}}
        self.pending = []
        self.running = []
        self.history = {}
        self.calls = []
        self.rejections = False
        self.queue_available = True
        self.next_id = 0
        self.content = bytes(range(256)) * 2048
        self.stream_gate = None
        state = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args):
                pass

            def send_json(self, value, status=200):
                payload = json.dumps(value).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self):
                parsed = urllib.parse.urlsplit(self.path)
                state.calls.append(("GET", parsed.path, self.headers.get("Range")))
                if parsed.path == "/object_info":
                    self.send_json(state.info)
                elif parsed.path == "/system_stats":
                    self.send_json({"devices": [], "system": {"comfyui_version": "test"}})
                elif parsed.path == "/queue":
                    if not state.queue_available:
                        self.send_json({"error": "temporarily unavailable"}, 503)
                    else:
                        self.send_json({"queue_pending": [[0, value] for value in state.pending],
                                        "queue_running": [[0, value] for value in state.running]})
                elif parsed.path.startswith("/history/"):
                    key = urllib.parse.unquote(parsed.path.rsplit("/", 1)[-1])
                    self.send_json({key: state.history[key]} if key in state.history else {})
                elif parsed.path == "/view":
                    query = urllib.parse.parse_qs(parsed.query)
                    if query.get("filename") != ["result.mp4"]:
                        self.send_json({"error": "unknown media"}, 404)
                        return
                    content = state.content
                    range_value = self.headers.get("Range")
                    match = re.fullmatch(r"bytes=(\d+)-(\d*)", range_value or "")
                    start, end = 0, len(content) - 1
                    if match:
                        start = int(match[1])
                        end = min(int(match[2]) if match[2] else end, end)
                        if start > end:
                            self.send_json({"error": "range not satisfiable"}, 416)
                            return
                    part = content[start:end + 1]
                    self.send_response(206 if match else 200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Length", str(len(part)))
                    self.send_header("Accept-Ranges", "bytes")
                    if match:
                        self.send_header("Content-Range", f"bytes {start}-{end}/{len(content)}")
                    self.end_headers()
                    first = 128 * 1024
                    try:
                        self.wfile.write(part[:first])
                        self.wfile.flush()
                        if state.stream_gate is not None and not match:
                            state.stream_gate.wait(5)
                        self.wfile.write(part[first:])
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                else:
                    self.send_json({"error": "not found"}, 404)

            def do_POST(self):
                path = urllib.parse.urlsplit(self.path).path
                body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                if path == "/upload/image":
                    state.calls.append(("POST", path, body))
                    match = re.search(br'filename="([^"]+)"', body)
                    self.send_json({"name": match[1].decode("ascii"), "subfolder": "", "type": "input"})
                    return
                data = json.loads(body)
                state.calls.append(("POST", path, data))
                if path == "/prompt":
                    if state.rejections:
                        self.send_json({"error": "bad graph", "node_errors": {"1": {"message": "backend rejected"}}}, 400)
                        return
                    state.next_id += 1
                    key = "job-" + str(state.next_id)
                    state.pending.append(key)
                    self.send_json({"prompt_id": key, "number": len(state.pending), "node_errors": {}})
                elif path == "/queue":
                    for key in data.get("delete", []):
                        if key in state.pending:
                            state.pending.remove(key)
                    self.send_json({})
                elif path == "/interrupt":
                    self.send_json({})
                else:
                    self.send_json({"error": "not found"}, 404)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={"poll_interval": 0.02}, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}"

    def stop(self):
        if self.stream_gate is not None:
            self.stream_gate.set()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)


class ServiceHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.web = self.root / "web"
        self.web.mkdir()
        (self.web / "index.html").write_text("<title>Test Canvas</title>", encoding="utf-8")
        (self.root / "private.txt").write_text("MUST_NOT_BE_SERVED", encoding="utf-8")
        self.backend = MockComfy()
        self.addCleanup(self.backend.stop)
        self.start_client()
        self.addCleanup(self.stop_client)

    def start_client(self):
        self.app = App(self.root / "data", self.web, self.backend.url)
        self.server = make_server(self.app)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={"poll_interval": 0.02}, daemon=True)
        self.thread.start()
        self.port = self.server.server_port
        status, _, payload = self.request("GET", "/api/bootstrap")
        self.assertEqual(status, 200)
        self.token = json.loads(payload)["csrf"]

    def stop_client(self):
        self.app.closed.set()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)

    def request(self, method, path, data=None, headers=None, raw=None, csrf=True):
        outgoing = {"Host": f"127.0.0.1:{self.port}"}
        body = raw
        if method == "POST":
            outgoing["Content-Type"] = "application/json"
            if csrf:
                outgoing["X-FW-Token"] = self.token
            if body is None:
                body = json.dumps({} if data is None else data).encode()
        outgoing.update(headers or {})
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        try:
            connection.request(method, path, body=body, headers=outgoing)
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def post(self, path, data=None, **kwargs):
        status, headers, body = self.request("POST", path, data, **kwargs)
        return status, headers, json.loads(body)

    def test_engine_and_update_controls_require_csrf(self):
        for path in ('/api/engines/start', '/api/engines/register', '/api/updates/check',
                     '/api/updates/stage', '/api/updates/install', '/api/exit'):
            with self.subTest(path=path):
                status, _, _ = self.post(path, {}, csrf=False)
                self.assertEqual(status, 403)
        self.assertFalse(self.app.closed.is_set())

    def test_engine_registration_does_not_accept_arbitrary_commands(self):
        status, _, body = self.post('/api/engines/register', {'root': str(self.root), 'arguments': ['bad']})
        self.assertEqual(status, 400)
        self.assertNotIn('profiles', body)

    def test_engine_list_and_update_status_do_not_trigger_generation(self):
        for path in ('/api/engines', '/api/updates', '/api/heartbeat'):
            status, _, _ = self.request('GET', path)
            self.assertEqual(status, 200)
        self.assertEqual(self.backend.next_id, 0)

    def submit(self):
        status, _, job = self.post("/api/jobs", copy.deepcopy(API_JOB))
        self.assertEqual(status, 200, job)
        return job

    def complete(self, job):
        key = job["id"]
        self.backend.pending.remove(key)
        self.backend.history[key] = {
            "status": {"status_str": "success", "completed": True},
            "outputs": {"1": {"videos": [{"filename": "result.mp4", "subfolder": "", "type": "output"}]}}
        }
        self.app.update_jobs()
        status, _, payload = self.request("GET", "/api/jobs")
        self.assertEqual(status, 200)
        output = next(value for value in json.loads(payload)["jobs"] if value["id"] == key)
        self.assertEqual(output["status"], "completed")
        return output["outputs"][0]["url"]

    def test_bootstrap_has_protective_headers_and_no_cors_grant(self):
        status, headers, payload = self.request("GET", "/api/bootstrap")
        self.assertEqual(status, 200)
        self.assertTrue(json.loads(payload)["csrf"])
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(headers["X-Frame-Options"], "DENY")
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])
        self.assertNotIn("Access-Control-Allow-Origin", headers)

    def test_package_import_apply_generate_and_video_result_roundtrip(self):
        status, _, inspection = self.post("/api/packages/inspect", {"document": API_JOB["prompt"]})
        self.assertEqual(status, 200, inspection)
        field = inspection["fields"][0]
        status, _, saved = self.post("/api/packages", {**inspection, "name": "Video package"})
        self.assertEqual(status, 200, saved)
        package_id = saved["package"]["id"]
        status, _, applied = self.post(f"/api/packages/{package_id}/apply", {"values": {field["id"]: "new film shot"}})
        self.assertEqual(status, 200, applied)
        self.assertEqual(applied["prompt"]["1"]["inputs"]["text"], "new film shot")
        self.assertFalse(any(call[:2] == ("POST", "/prompt") for call in self.backend.calls))
        status, _, job = self.post("/api/jobs", {"kind": "package", "package_id": package_id, "values": {field["id"]: "new film shot"}})
        self.assertEqual(status, 200, job)
        prompt_call = next(call for call in self.backend.calls if call[:2] == ("POST", "/prompt"))
        self.assertEqual(prompt_call[2]["prompt"]["1"]["inputs"]["text"], "new film shot")
        url = self.complete(job)
        self.assertEqual(self.request("GET", url, headers={"Range": "bytes=0-15"})[2], self.backend.content[:16])
        status, _, exported = self.post(f"/api/packages/{package_id}/export")
        self.assertEqual(status, 200)
        self.assertNotIn("new film shot", json.dumps(exported))
        status, _, again = self.post("/api/packages", exported["document"])
        self.assertEqual(again["package"]["id"], package_id)

    def test_package_import_works_offline_and_never_calls_backend(self):
        self.app.backend.url = "http://127.0.0.1:1"
        status, _, inspected = self.post("/api/packages/inspect", {"document": API_JOB["prompt"]})
        self.assertEqual(status, 200)
        status, _, saved = self.post("/api/packages", {**inspected, "name": "Offline"})
        self.assertEqual(status, 200)
        self.assertFalse(self.backend.calls)
        status, _, body = self.request("GET", "/api/packages")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["packages"][0]["id"], saved["package"]["id"])

    def test_package_raw_transport_preserves_float_id_without_backend_calls(self):
        status, _, draft = self.post("/api/packages/inspect", {"source_json": json.dumps(API_JOB["prompt"])})
        self.assertEqual(status, 200, draft)
        draft["prompt"]["1"]["inputs"]["cfg"] = 7.0
        draft["prompt"]["1"]["inputs"]["denoise"] = 1.0
        status, _, saved = self.post("/api/packages", {"source_json": json.dumps(draft)})
        self.assertEqual(status, 200, saved)
        package_id = saved["package"]["id"]
        status, _, exported = self.post(f"/api/packages/{package_id}/export")
        self.assertEqual(status, 200, exported)
        self.assertIn('"denoise":1.0', exported["source_json"])
        self.assertEqual(json.loads(exported["source_json"]), exported["document"])
        status, _, inspected = self.post("/api/packages/inspect", {"source_json": exported["source_json"]})
        self.assertEqual(status, 200, inspected)
        status, _, imported = self.post("/api/packages", {"source_json": exported["source_json"]})
        self.assertEqual(status, 200, imported)
        self.assertEqual(imported["package"]["id"], package_id)
        self.assertEqual(len(self.app.packages.list()), 1)
        self.assertEqual(self.backend.calls, [])

    def test_package_raw_transport_rejects_invalid_carriers_and_preserves_csrf(self):
        for path in ("/api/packages/inspect", "/api/packages"):
            for payload in ({"source_json": []}, {"source_json": "[]"}, {"source_json": "{"},
                            {"source_json": '{"x":1,"x":2}'},
                            {"source_json": "{}", "document": API_JOB["prompt"]}):
                with self.subTest(path=path, payload=payload):
                    self.assertEqual(self.post(path, payload)[0], 400)
                    self.assertEqual(self.post(path, payload, csrf=False)[0], 403)
            self.assertEqual(self.post(path, {"source_json": "{}"}, headers={"Origin": "https://other.test"})[0], 403)
            self.assertEqual(self.post(path, {"source_json": "{}"}, headers={"Host": "other.test"})[0], 403)
        self.assertEqual(self.app.packages.list(), [])
        self.assertEqual(self.backend.calls, [])

    def test_package_raw_transport_rejects_oversized_utf8_source(self):
        source = '{"name":"' + "图" * (1024 * 1024) + '"}'
        for path in ("/api/packages/inspect", "/api/packages"):
            status, _, result = self.post(path, {"source_json": source})
            self.assertEqual(status, 400, result)
            self.assertIn("2 MiB", result["error"])
        self.assertEqual(self.app.packages.list(), [])
        self.assertEqual(self.backend.calls, [])

    def test_package_endpoints_reject_invalid_inputs_and_cross_site_writes(self):
        for path, body in (("/api/packages/inspect", {"document": []}),
                           ("/api/packages/inspect", {"document": {"nodes": [], "links": []}}),
                           ("/api/packages", {"name": "broken"}),
                           ("/api/jobs", {"kind": "package", "package_id": "../../outside"})):
            self.assertEqual(self.post(path, body)[0], 400, path)
            self.assertEqual(self.post(path, body, csrf=False)[0], 403)
        self.assertFalse(any(call[:2] == ("POST", "/prompt") for call in self.backend.calls))

    def test_environment_cache_does_not_mutate_settings_or_repeat_probe(self):
        snapshot = {"checks": [], "candidates": [{"url": "http://127.0.0.1:8190", "online": True}], "installations": [], "hardware": {}}
        before = copy.deepcopy(self.app.settings)
        with patch("frameweave.server.discover_environment", return_value=snapshot) as discovery:
            self.assertEqual(self.post("/api/environment")[2], snapshot)
            self.assertEqual(self.post("/api/environment")[2], snapshot)
            self.assertEqual(discovery.call_count, 1)
        self.assertEqual(self.app.settings, before)
        self.assertEqual(self.post("/api/environment", csrf=False)[0], 403)

    def test_deep_json_is_rejected_and_server_remains_available(self):
        raw = b'{"document":' + b"[" * 2000 + b"0" + b"]" * 2000 + b"}"
        self.assertEqual(self.request("POST", "/api/packages/inspect", raw=raw)[0], 400)
        self.assertEqual(self.request("GET", "/api/bootstrap")[0], 200)

    def test_upload_cannot_change_backend_midway(self):
        entered, release, switched = threading.Event(), threading.Event(), threading.Event()
        errors, results = [], []
        original = self.app.backend.upload
        def blocked_upload(*args):
            entered.set()
            release.wait(2)
            return original(*args)
        def upload():
            try:
                results.append(self.app.upload({"data": base64.b64encode(PNG).decode()}))
            except Exception as exc:
                errors.append(exc)
        def switch():
            self.app.save_settings({"backend_url": "http://127.0.0.1:8189", "model_roots": []})
            switched.set()
        with patch.object(self.app.backend, "upload", side_effect=blocked_upload):
            uploader = threading.Thread(target=upload)
            uploader.start()
            self.assertTrue(entered.wait(1))
            switcher = threading.Thread(target=switch)
            switcher.start()
            self.assertFalse(switched.wait(.05))
            release.set()
            uploader.join(2)
            switcher.join(2)
        self.assertFalse(errors)
        self.assertTrue(switched.is_set())
        self.assertEqual(results[0]['backend'], self.backend.url)
        self.assertTrue(self.app.media)
        self.assertTrue(all(backend == self.backend.url for backend, _ in self.app.media.values()))

    def test_comfy_roots_saved_without_erasing_other_settings(self):
        root = str(self.root.resolve())
        status, _, saved = self.post("/api/settings", {"backend_url": self.backend.url, "model_roots": [], "comfy_roots": [root]})
        self.assertEqual(status, 200)
        self.assertEqual(saved["settings"]["comfy_roots"], [root])
        status, _, saved = self.post("/api/settings", {"backend_url": self.backend.url, "model_roots": []})
        self.assertEqual(saved["settings"]["comfy_roots"], [root])

    def test_host_origin_and_csrf_reject_cross_site_access(self):
        for headers in ({"Host": "attacker.invalid"}, {"Origin": "https://attacker.invalid"},
                        {"Sec-Fetch-Site": "cross-site"}):
            with self.subTest(headers=headers):
                self.assertEqual(self.request("GET", "/api/bootstrap", headers=headers)[0], 403)
        for headers in ({"Host": "attacker.invalid"}, {"Origin": "https://attacker.invalid"},
                        {"X-FW-Token": "invalid"}):
            with self.subTest(headers=headers):
                self.assertEqual(self.post("/api/jobs", API_JOB, headers=headers)[0], 403)
        self.assertEqual(self.post("/api/jobs", API_JOB, csrf=False)[0], 403)
        self.assertEqual(self.request("OPTIONS", "/api/jobs")[0], 403)
        self.assertFalse(self.backend.calls)

    def test_early_rejection_sends_response_before_draining_small_body(self):
        body = json.dumps(API_JOB).encode()
        host = f"127.0.0.1:{self.port}"
        cases = (
            {"Host": "attacker.invalid", "X-FW-Token": self.token},
            {"Host": host, "X-FW-Token": "invalid"},
        )
        backend_calls = list(self.backend.calls)
        for override in cases:
            with self.subTest(override=override):
                sock = socket.create_connection(("127.0.0.1", self.port), timeout=2)
                try:
                    sock.settimeout(2)
                    headers = {"Host": host, "Content-Type": "application/json",
                               "Content-Length": str(len(body)), "Connection": "keep-alive",
                               "X-FW-Token": self.token, **override}
                    lines = ["POST /api/jobs HTTP/1.1", *(f"{key}: {value}" for key, value in headers.items()), "", ""]
                    sock.sendall("\r\n".join(lines).encode("ascii"))
                    response = http.client.HTTPResponse(sock)
                    response.begin()
                    self.assertEqual(response.status, 403)
                    self.assertEqual(response.getheader("Connection"), "close")
                    self.assertIn(b"\xe8\xaf\xb7\xe6\xb1\x82\xe6\xa0\xa1\xe9\xaa\x8c\xe5\xa4\xb1\xe8\xb4\xa5",
                                  response.read())
                    # Send the declared, valid JSON only after the complete
                    # rejection has reached the client.
                    sock.sendall(body)
                    self.assertEqual(sock.recv(1), b"")
                finally:
                    sock.close()
        self.assertEqual(self.backend.calls, backend_calls)
        self.assertFalse(self.app.jobs)

    def test_rejected_body_drain_is_bounded_for_idle_oversized_and_unknown_bodies(self):
        host = f"127.0.0.1:{self.port}"
        cases = (
            ({"Host": host, "X-FW-Token": self.token,
              "Content-Length": str(MAX_JSON + 1)}, 413),
            ({"Host": host, "X-FW-Token": self.token}, 413),
            ({"Host": host, "X-FW-Token": self.token,
              "Transfer-Encoding": "chunked"}, 400),
        )
        backend_calls = list(self.backend.calls)
        for headers, expected in cases:
            with self.subTest(headers=headers):
                sock = socket.create_connection(("127.0.0.1", self.port), timeout=2)
                try:
                    sock.settimeout(2)
                    request_headers = {"Content-Type": "application/json", **headers}
                    lines = ["POST /api/jobs HTTP/1.1",
                             *(f"{key}: {value}" for key, value in request_headers.items()), "", ""]
                    sock.sendall("\r\n".join(lines).encode("ascii"))
                    response = http.client.HTTPResponse(sock)
                    response.begin()
                    self.assertEqual(response.status, expected)
                    self.assertEqual(response.getheader("Connection"), "close")
                    response.read()
                    self.assertEqual(sock.recv(1), b"")
                finally:
                    sock.close()
        self.assertEqual(self.backend.calls, backend_calls)

    def test_rejected_small_body_idle_drain_has_a_short_deadline(self):
        sock = socket.create_connection(("127.0.0.1", self.port), timeout=2)
        try:
            sock.settimeout(2)
            headers = {"Host": f"127.0.0.1:{self.port}", "Content-Type": "application/json",
                       "Content-Length": "8", "X-FW-Token": "invalid", "Connection": "keep-alive"}
            lines = ["POST /api/jobs HTTP/1.1", *(f"{key}: {value}" for key, value in headers.items()), "", ""]
            started = time.monotonic()
            sock.sendall("\r\n".join(lines).encode("ascii"))
            response = http.client.HTTPResponse(sock)
            response.begin()
            self.assertEqual(response.status, 403)
            response.read()
            self.assertEqual(sock.recv(1), b"")
            self.assertLess(time.monotonic() - started, 1.5)
        finally:
            sock.close()
        self.assertFalse(self.backend.calls)

    def test_bad_json_content_type_and_request_length_are_rejected(self):
        for raw in (b"{", b"[]", b"null", b'{"steps":NaN}', b'{"steps":Infinity}'):
            with self.subTest(raw=raw):
                self.assertEqual(self.post("/api/jobs", raw=raw)[0], 400)
        self.assertEqual(self.post("/api/jobs", API_JOB, headers={"Content-Type": "text/plain"})[0], 415)
        for length in ("0", "-1", str(29 * 1024 * 1024)):
            with self.subTest(length=length):
                self.assertEqual(self.post("/api/jobs", raw=b"", headers={"Content-Length": length})[0], 413)
        self.assertFalse(self.backend.calls)

    def test_settings_only_accept_local_backend_and_local_absolute_roots(self):
        bad_urls = ("https://127.0.0.1:8188", "http://example.com:8188", "http://192.168.1.1:8188",
                    "http://user:password@127.0.0.1:8188", "http://127.0.0.1:8188/path",
                    "http://127.0.0.1:8188?token=secret")
        for value in bad_urls:
            with self.subTest(url=value):
                self.assertEqual(self.post("/api/settings", {"backend_url": value})[0], 400)
        for roots in (["relative/models"], ["//server/share"], "not a list"):
            with self.subTest(roots=roots):
                status, _, _ = self.post("/api/settings", {"backend_url": self.backend.url, "model_roots": roots})
                self.assertEqual(status, 400)
        status, _, result = self.post("/api/settings", {
            "backend_url": self.backend.url.replace("127.0.0.1", "localhost"),
            "model_roots": [str(self.root), str(self.root)]})
        self.assertEqual(status, 200)
        self.assertEqual(result["settings"]["backend_url"], self.backend.url)
        saved = json.loads((self.root / "data" / "settings.json").read_text(encoding="utf-8"))
        self.assertEqual(saved["model_roots"], [str(self.root.resolve())])

    def test_static_file_traversal_cannot_expose_sibling_files(self):
        for path in ("/../private.txt", "/%2e%2e/private.txt", "/%2e%2e%5cprivate.txt",
                     "/C%3a/private.txt", "/missing.html"):
            with self.subTest(path=path):
                status, _, body = self.request("GET", path)
                self.assertIn(status, (400, 404))
                self.assertNotIn(b"MUST_NOT_BE_SERVED", body)
        status, _, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"Test Canvas", body)

    def test_upload_uses_content_type_and_generated_name(self):
        for content in (b"<svg onload='alert(1)'/>", b"<html>not image</html>", b"MZexecutable data"):
            with self.subTest(content=content):
                status, _, _ = self.post("/api/upload", {"name": "image.png", "data": base64.b64encode(content).decode()})
                self.assertEqual(status, 400)
        self.assertEqual(self.post("/api/upload", {"data": "not base64!"})[0], 400)
        self.assertFalse(self.backend.calls)
        status, _, result = self.post("/api/upload", {
            "name": "../../injected.svg", "mime": "text/html", "data": base64.b64encode(PNG).decode()})
        self.assertEqual(status, 200, result)
        self.assertRegex(result["name"], r"^frameweave-[a-f0-9]{32}\.png$")
        self.assertRegex(result["url"], r"^/api/media/[a-f0-9]{32}$")
        uploaded = next(call[2] for call in self.backend.calls if call[:2] == ("POST", "/upload/image"))
        self.assertIn(PNG, uploaded)
        self.assertIn(b"Content-Type: image/png", uploaded)
        self.assertNotIn(b"injected.svg", uploaded)

    def test_compile_rejection_never_reaches_backend_prompt(self):
        invalid = {"kind": "api", "prompt": {"1": {"class_type": "UninstalledNode", "inputs": {}}}}
        status, _, result = self.post("/api/jobs", invalid)
        self.assertEqual(status, 400, result)
        self.assertFalse(any(call[:2] == ("POST", "/prompt") for call in self.backend.calls))
        self.assertEqual(json.loads(self.request("GET", "/api/jobs")[2])["jobs"], [])

    def test_backend_rejection_does_not_create_phantom_job_and_can_recover(self):
        self.backend.rejections = True
        status, _, result = self.post("/api/jobs", API_JOB)
        self.assertEqual(status, 502, result)
        self.assertEqual(json.loads(self.request("GET", "/api/jobs")[2])["jobs"], [])
        self.backend.rejections = False
        job = self.submit()
        self.assertEqual(job["status"], "queued")
        posted = [call[2] for call in self.backend.calls if call[:2] == ("POST", "/prompt")][-1]
        self.assertEqual(posted["prompt"], API_JOB["prompt"])
        self.assertTrue(posted["client_id"])

    def test_pending_cancel_only_deletes_owned_job(self):
        job = self.submit()
        self.backend.pending.append("foreign-job")
        status, _, _ = self.post("/api/jobs/foreign-job/cancel")
        self.assertEqual(status, 400)
        status, _, result = self.post(f"/api/jobs/{job['id']}/cancel")
        self.assertEqual(status, 200, result)
        self.assertEqual(result["status"], "cancelled")
        self.assertEqual(self.backend.pending, ["foreign-job"])
        changes = [call for call in self.backend.calls if call[:2] == ("POST", "/queue")]
        self.assertEqual([call[2] for call in changes], [{"delete": [job["id"]]}])
        self.assertFalse(any(call[:2] == ("POST", "/interrupt") for call in self.backend.calls))

    def test_running_cancel_never_uses_shared_global_interrupt(self):
        job = self.submit()
        self.backend.pending.remove(job["id"])
        self.backend.running.extend([job["id"], "foreign-running"])
        status, _, _ = self.post(f"/api/jobs/{job['id']}/cancel")
        self.assertEqual(status, 400)
        self.assertEqual(self.backend.running, [job["id"], "foreign-running"])
        self.assertFalse(any(call[0] == "POST" and call[1] in ("/queue", "/interrupt") for call in self.backend.calls))

    def test_disconnect_preserves_job_and_history_recovers_after_restart(self):
        job = self.submit()
        self.backend.queue_available = False
        self.app.update_jobs()
        jobs = json.loads(self.request("GET", "/api/jobs")[2])["jobs"]
        self.assertEqual(jobs[0]["status"], "queued")
        self.backend.queue_available = True
        self.stop_client()
        self.start_client()
        restored = json.loads(self.request("GET", "/api/jobs")[2])["jobs"]
        self.assertEqual(restored[0]["id"], job["id"])
        self.assertEqual(restored[0]["status"], "queued")
        url = self.complete(job)
        self.assertRegex(url, r"^/api/media/[a-f0-9]{32}$")

    def test_backend_change_is_blocked_until_owned_jobs_finish(self):
        job = self.submit()
        status, _, _ = self.post("/api/settings", {"backend_url": "http://127.0.0.1:9"})
        self.assertEqual(status, 400)
        self.assertEqual(self.app.backend.url, self.backend.url)
        self.post(f"/api/jobs/{job['id']}/cancel")
        self.assertEqual(self.post("/api/settings", {"backend_url": "http://127.0.0.1:9"})[0], 200)

    def test_unowned_media_cannot_proxy_backend_arbitrary_files(self):
        status, _, _ = self.request("GET", "/api/media/" + "0" * 32 + "?filename=private.txt")
        self.assertEqual(status, 404)
        self.assertFalse(any(call[:2] == ("GET", "/view") for call in self.backend.calls))

    def test_owned_result_media_forwards_range_and_exact_bytes(self):
        url = self.complete(self.submit())
        status, headers, content = self.request("GET", url, headers={"Range": "bytes=17-300"})
        self.assertEqual(status, 206)
        self.assertEqual(content, self.backend.content[17:301])
        self.assertEqual(headers["Content-Range"], f"bytes 17-300/{len(self.backend.content)}")
        self.assertEqual(headers["Accept-Ranges"], "bytes")
        self.assertEqual(headers["Content-Type"], "video/mp4")
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertIn(("GET", "/view", "bytes=17-300"), self.backend.calls)

    def test_owned_media_streams_before_backend_finishes_body(self):
        url = self.complete(self.submit())
        gate = threading.Event()
        self.backend.stream_gate = gate
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=2)
        try:
            connection.request("GET", url)
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            prefix = response.read(64)
            self.assertEqual(prefix, self.backend.content[:64])
            self.assertFalse(gate.is_set(), "first bytes must arrive before backend is allowed to finish")
            gate.set()
            self.assertEqual(prefix + response.read(), self.backend.content)
        finally:
            gate.set()
            connection.close()


if __name__ == "__main__":
    unittest.main()
