# 棱光 PrismCanvas 0.11.8

完整解压 ZIP 后启动 PrismCanvas.exe。支持 Windows x64，独立窗口需要 .NET 8 Desktop Runtime（x64）和 Microsoft Edge WebView2 Runtime。连接已有的本机 ComfyUI 后可生成内容。应用数据保存在单独的工作区。

进入图片、视频或声音工作台，打开「工作流与模型」。选择工作流包、输出和加载器的模型后添加到画布。检查器显示字段对应的内部节点与输入。可在「管理外部接口」调整公开参数、连线和输出。

项目与用户手册：https://github.com/NOXEVYR/frameweave
发行记录：https://github.com/NOXEVYR/frameweave/releases/tag/v0.11.8
