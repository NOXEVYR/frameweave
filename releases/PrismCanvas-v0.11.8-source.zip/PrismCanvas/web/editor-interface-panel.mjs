/** User-facing choices for exposing native ComfyUI controls on the outer canvas. */
import { MAX_INTERFACE_FIELDS, DEFAULT_INTERFACE_FIELDS } from './interface-limits.mjs';
import { interfacePage, interfaceSearch } from './interface-pagination.mjs';

export const EDITOR_INTERFACE_GROUPS = Object.freeze([
  '模型与编码器', '提示词', '媒体', '采样尺寸', '其他',
]);
export const EDITOR_INTERFACE_FIELD_LIMIT = MAX_INTERFACE_FIELDS;
export const EDITOR_INTERFACE_CANDIDATE_LIMIT = MAX_INTERFACE_FIELDS;
export const EDITOR_INTERFACE_OUTPUT_LIMIT = 64;
const FIELD_DISCONNECT = null;

const idOf = value => {
  if (value === null || value === undefined) return '';
  if (typeof value === 'object') return idOf(value.id ?? value.fieldId ?? value.field_id ?? value.outputId ?? value.output_id);
  return String(value);
};
const fieldId = field => idOf(field?.id ?? field?.fieldId ?? field?.field_id ?? field);
const outputId = output => idOf(output?.id ?? output?.outputId ?? output?.output_id ?? output);
const plainObjectEntries = value => value instanceof Map ? [...value.entries()] :
  (value && typeof value === 'object' && !Array.isArray(value) ? Object.entries(value) : []);
const hasKey = (value, key) => value instanceof Map ? value.has(key) :
  !!value && typeof value === 'object' && Object.hasOwn(value, key);
const getKey = (value, key) => value instanceof Map ? value.get(key) : value?.[key];
const normalizedType = value => String(value ?? '').trim().toLowerCase();
const typeOf = field => Array.isArray(field?.type) ? field.type.map(normalizedType).filter(Boolean).join('|') : normalizedType(field?.type);
const mediaTokens = field => [field?.type, field?.mediaType]
  .flatMap(value => Array.isArray(value) ? value : [value]).map(normalizedType);

export function isRequiredEditorMediaField(field) {
  return mediaTokens(field).some(value => ['image', 'audio', 'video'].includes(value));
}

export function editorFieldSupportsPort(field) {
  return ['text', 'string', 'image', 'video', 'audio'].includes(typeOf(field));
}

function fieldPresentation(field, previous) {
  if (!editorFieldSupportsPort(field)) return 'control';
  if (previous?.presentation === 'port' || previous?.presentation === 'control') return previous.presentation;
  if (field.presentation === 'port' || field.presentation === 'control') return field.presentation;
  // Older interfaces exposed all connectable types. Preserve that behavior on recompilation.
  if (previous && typeof previous === 'object') return 'port';
  return ['image', 'video', 'audio'].includes(typeOf(field)) || editorFieldGroup(field) === '提示词' ? 'port' : 'control';
}

function retainedField(field, previousFields) {
  const match = previousFields instanceof Map ? previousFields.get(fieldId(field)) : previousFields.find(item => previousFieldId(item) === fieldId(field));
  const previous = match && typeof match === 'object' && sameKnownType(match, field) ? match : undefined;
  return { ...field, ...(previous?.label !== undefined ? { label: previous.label } : {}),
    presentation: fieldPresentation(field, previous) };
}

export function editorFieldGroup(field) {
  if (EDITOR_INTERFACE_GROUPS.includes(field?.group)) return field.group;
  if (mediaTokens(field).some(value => ['image', 'audio', 'video', 'mask'].includes(value))) return '媒体';
  const roles = { model: '模型与编码器', encoder: '模型与编码器', lora: '模型与编码器',
    prompt: '提示词', positive_prompt: '提示词', negative_prompt: '提示词',
    seed: '采样尺寸', sampling: '采样尺寸', size: '采样尺寸', custom: '其他' };
  if (roles[field?.role]) return roles[field.role];
  const type = typeOf(field);
  const text = [field?.input, field?.label].flatMap(value => Array.isArray(value) ? value : [value])
    .filter(value => value !== undefined && value !== null).join(' ').toLowerCase();
  if (/model|checkpoint|ckpt|vae|lora|clip|encoder|unet|diffusion|safetensor|gguf/.test(`${type} ${text}`)) return '模型与编码器';
  if (/prompt|positive|negative|caption|text|文本|提示词|正向|反向/.test(text)) return '提示词';
  if (/width|height|size|seed|steps|cfg|sampler|scheduler|denoise|noise|batch|fps|seconds|frames|shift|尺寸|采样|种子|步数|强度/.test(text)) return '采样尺寸';
  return '其他';
}

export function editorFieldTypeCompatible(left, right) {
  const a = normalizedType(typeof left === 'object' && left !== null ? left.type : left);
  const b = normalizedType(typeof right === 'object' && right !== null ? right.type : right);
  return !!a && !!b && a === b;
}

function sameKnownType(left, right) {
  const a = typeOf(left), b = typeOf(right);
  return !a || !b || a === b;
}

function previousFieldId(item) {
  return typeof item === 'string' || typeof item === 'number' ? String(item) : fieldId(item);
}

function defaultEditorFieldIds(fields, previousFields, previousValues, previousBaseline, limit) {
  const candidates = Array.isArray(fields) ? fields : [];
  const previous = Array.isArray(previousFields) ? previousFields : [];
  const previousById = new Map(previous.map(item => [previousFieldId(item), item]).filter(([id]) => id));
  const previousIds = new Set((previous.length
    ? previous.filter(item => item?.selected !== false).map(previousFieldId)
    : [
      ...plainObjectEntries(previousValues).map(([key]) => String(key)),
      ...plainObjectEntries(previousBaseline).map(([key]) => String(key)),
    ]).filter(Boolean));
  const hasPrevious = previous.length > 0 || plainObjectEntries(previousValues).length > 0 ||
    plainObjectEntries(previousBaseline).length > 0;
  const required = candidates.filter(isRequiredEditorMediaField);
  const wanted = hasPrevious
    ? candidates.filter(field => {
      const id = fieldId(field), old = previousById.get(id);
      return previousIds.has(id) && (!old || typeof old !== 'object' || sameKnownType(old, field));
    })
    : candidates.filter(field => field.recommended === true ||
      field.recommended === undefined && ['模型与编码器', '提示词', '采样尺寸'].includes(editorFieldGroup(field)));
  const ordered = [...required, ...wanted.filter(field => !required.includes(field))];
  const capped = hasPrevious || required.length > limit ? ordered : ordered.slice(0, limit);
  return capped.map(fieldId).filter(Boolean);
}

export function initialEditorFieldIds(fields, previousFields = [], previousValues = {}, previousBaseline = {}) {
  return defaultEditorFieldIds(fields, previousFields, previousValues, previousBaseline, DEFAULT_INTERFACE_FIELDS);
}

export function initialEditorOutputIds(outputs, selectedOutputs = []) {
  const candidates = Array.isArray(outputs) ? outputs : [];
  const selected = Array.isArray(selectedOutputs) ? selectedOutputs : [];
  if (!selected.length) return candidates.map(outputId).filter(Boolean);
  const priorIds = new Set(selected.map(outputId).filter(Boolean));
  return candidates.map(outputId).filter(id => id && priorIds.has(id));
}

function fieldDisplay(field, fallbackId = '') {
  return {
    id: fieldId(field) || fallbackId,
    label: String(field?.label ?? field?.input ?? fallbackId ?? '旧参数'),
    type: field?.type,
    node_id: field?.node_id,
    input: field?.input,
  };
}

function connectionCounts(connections, direction, property) {
  const counts = new Map();
  for (const item of Array.isArray(connections) ? connections : []) {
    if (item?.direction !== direction) continue;
    const id = idOf(item?.[property]);
    if (id) counts.set(id, (counts.get(id) || 0) + 1);
  }
  return counts;
}

export function deriveEditorRebindings({
  fields = [], previousFields = [], selectedFieldIds = [], outputs = [], selectedOutputIds = [],
  selectedOutputs = [], connections = [], replaced_nodes: replacedNodes = {},
} = {}) {
  const fieldList = Array.isArray(fields) ? fields : [];
  const outputList = Array.isArray(outputs) ? outputs : [];
  const currentFields = new Map(fieldList.map(item => [fieldId(item), item]));
  // Share compatible candidates instead of retaining an N-by-N array of
  // references when a large interface replaces every prior field.
  const candidatesByType = new Map();
  for (const field of fieldList) {
    const type = typeOf(field);
    if (!type) continue;
    if (!candidatesByType.has(type)) candidatesByType.set(type, []);
    candidatesByType.get(type).push(field);
  }
  for (const group of candidatesByType.values()) Object.freeze(group);
  const currentOutputs = new Map(outputList.map(item => [outputId(item), item]));
  const selectedFields = new Set((selectedFieldIds || []).map(idOf).filter(Boolean));
  const selectedOutputSet = new Set((selectedOutputIds || []).map(idOf).filter(Boolean));
  const previousById = new Map((Array.isArray(previousFields) ? previousFields : [])
    .filter(item => item?.selected !== false).map(item => [previousFieldId(item), item]).filter(([id]) => id));
  const selectedOutputById = new Map((Array.isArray(selectedOutputs) ? selectedOutputs : [])
    .map(item => [outputId(item), item]).filter(([id]) => id));
  const inputCounts = connectionCounts(connections, 'input', 'fieldId');
  const outputCounts = connectionCounts(connections, 'output', 'outputId');
  const inputConnections = new Map();
  const outputConnections = new Map();
  for (const connection of Array.isArray(connections) ? connections : []) {
    if (connection?.direction === 'input') {
      const id = idOf(connection.fieldId);
      if (id && !inputConnections.has(id)) inputConnections.set(id, connection);
    } else if (connection?.direction === 'output') {
      const id = idOf(connection.outputId ?? connection.output_id ?? connection.id);
      if (id && !outputConnections.has(id)) outputConnections.set(id, connection);
    }
  }

  const inputIds = new Set([...previousById.keys(), ...inputCounts.keys()]);
  const inputRebindings = [];
  for (const id of inputIds) {
    const current = currentFields.get(id);
    const prior = previousById.get(id);
    const connection = inputConnections.get(id);
    const old = prior && typeof prior === 'object' ? prior : connection || current || { id };
    const oldType = typeOf(old) || typeOf(connection) || typeOf(current);
    const typeChanged = !!current && !!oldType && !!typeOf(current) && oldType !== typeOf(current);
    const connected = inputCounts.get(id) || 0;
    if (current && selectedFields.has(id) && !typeChanged) continue;
    const removedOrChanged = !current || typeChanged;
    if (!removedOrChanged && !connected) continue;
    const descriptor = fieldDisplay(old, id);
    descriptor.type = old.type ?? connection?.type ?? current?.type;
    descriptor.connected = connected;
    descriptor.reason = old.node_id && Object.hasOwn(replacedNodes, old.node_id) ? 'node_replaced' : !current ? 'removed' : typeChanged ? 'type_changed' : 'not_exposed';
    const group = candidatesByType.get(typeOf(descriptor)) || [];
    const includesSelf = current && typeOf(current) === typeOf(descriptor);
    Object.defineProperty(descriptor, 'candidates', { enumerable: true, get: () =>
      includesSelf ? group.filter(candidate => fieldId(candidate) !== id) : group });
    inputRebindings.push(descriptor);
  }

  const outputIds = new Set(outputCounts.keys());
  const outputRebindings = [];
  for (const id of outputIds) {
    const current = currentOutputs.get(id);
    const prior = selectedOutputById.get(id);
    const connection = outputConnections.get(id);
    const oldMediaType = normalizedType(prior?.mediaType) || normalizedType(connection?.mediaType) || normalizedType(prior?.type);
    const currentMediaType = normalizedType(current?.mediaType ?? current?.type);
    const typeChanged = !!current && !!oldMediaType && !!currentMediaType && oldMediaType !== currentMediaType;
    if (selectedOutputSet.has(id) && current && !typeChanged && current.replaced !== true) continue;
    const old = prior && typeof prior === 'object' ? prior : connection || current || { id };
    const mediaType = oldMediaType || normalizedType(old.mediaType ?? old.type ?? currentMediaType);
    const descriptor = {
      id,
      label: String(old.label ?? connection?.label ?? current?.label ?? id),
      mediaType,
      connected: outputCounts.get(id) || 0,
      reason: current?.replaced === true ? 'node_replaced' : typeChanged ? 'type_changed' : !current ? 'removed' : 'not_selected',
      candidates: outputList.filter(candidate => {
        const candidateId = outputId(candidate);
        if (!candidateId || candidateId === id && current?.replaced !== true) return false;
        const candidateType = normalizedType(candidate.mediaType);
        return !mediaType || !candidateType || candidateType === mediaType;
      }),
    };
    outputRebindings.push(descriptor);
  }
  return { inputRebindings, outputRebindings };
}

export function shortValuePreview(value, limit = 72) {
  let text;
  if (value === undefined) text = '（无值）';
  else if (typeof value === 'string') text = value.replace(/\s+/g, ' ').trim() || '（空文本）';
  else {
    try { text = JSON.stringify(value); } catch { text = String(value); }
    if (text === undefined) text = String(value);
  }
  return text.length > limit ? `${text.slice(0, Math.max(0, limit - 1))}…` : text;
}

function sameJsonValue(left, right) {
  try { return JSON.stringify(left) === JSON.stringify(right); } catch { return Object.is(left, right); }
}

function element(tag, text = '', className = '') {
  const item = document.createElement(tag);
  if (text !== undefined && text !== null) item.textContent = String(text);
  if (className) item.className = className;
  return item;
}

const PANEL_STYLE = `
  .editor-interface-dialog{padding:0;border:1px solid var(--line);border-radius:15px;color:var(--text);background:var(--panel);
    width:min(980px,calc(100vw - 28px));max-width:none;max-height:calc(100dvh - 28px);overflow:hidden;box-shadow:0 24px 90px #26396a1c}
  .editor-interface-dialog::backdrop{background:#17234170;backdrop-filter:blur(3px)}
  .editor-interface-layout{display:grid;grid-template-rows:auto minmax(0,1fr) auto;max-height:calc(100dvh - 28px);min-height:min(560px,calc(100dvh - 28px))}
  .editor-interface-header,.editor-interface-footer{position:sticky;z-index:2;background:var(--panel);padding:15px 20px;display:flex;align-items:center;gap:12px}
  .editor-interface-header{top:0;border-bottom:1px solid var(--line)}.editor-interface-header-copy{min-width:0;flex:1}
  .editor-interface-header h2{margin:0;font-size:19px}.editor-interface-header p{margin:5px 0 0;color:var(--muted);font-size:12px;line-height:1.55}
  .editor-interface-close{flex:0 0 auto}.editor-interface-body{overflow:auto;overscroll-behavior:contain;padding:16px 20px}
  .editor-interface-footer{bottom:0;justify-content:space-between;border-top:1px solid var(--line)}
  .editor-interface-footer .editor-interface-actions{display:flex;justify-content:flex-end;gap:8px;margin-left:auto}
  .editor-interface-status{margin:0;color:var(--muted);font-size:12px;line-height:1.5}.editor-interface-status[data-error="true"]{color:var(--danger)}
  .editor-interface-toolbar{display:grid;grid-template-columns:minmax(180px,1fr) auto;gap:11px;align-items:center;margin-bottom:12px}
  .editor-interface-search{width:100%;min-height:36px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--panel);color:var(--muted)}
  .editor-interface-tabs{display:flex;gap:5px;flex-wrap:wrap;justify-content:flex-end}
  .editor-interface-tab{border:1px solid var(--line);border-radius:99px;padding:6px 9px;background:var(--panel);color:var(--muted);font-size:11px;cursor:pointer}
  .editor-interface-tab[aria-pressed="true"]{background:var(--accent-dim);border-color:var(--accent-line);color:var(--accent-text)}
  .editor-interface-count{margin:5px 0 10px;color:var(--muted);font-size:12px}
  .editor-interface-group{border:1px solid var(--line);border-radius:10px;background:var(--panel);margin:10px 0;overflow:hidden}
  .editor-interface-group h3,.editor-interface-section h3{font-size:13px;margin:0;padding:10px 12px;color:var(--muted);background:var(--panel)}
  .editor-interface-field{display:grid;grid-template-columns:auto minmax(0,1fr) minmax(145px,230px);align-items:center;gap:10px;padding:9px 12px;border-top:1px solid var(--line)}
  .editor-interface-field:first-of-type{border-top:0}.editor-interface-field input[type="checkbox"]{width:16px;height:16px;accent-color:var(--accent)}
  .editor-interface-field-main{min-width:0}.editor-interface-field-title{font-size:12px;font-weight:600;overflow-wrap:anywhere}
  .editor-interface-field-meta{margin-top:3px;color:var(--muted);font-size:10px;overflow-wrap:anywhere}
  .editor-interface-field-name{width:100%;min-width:0;min-height:32px;padding:5px 8px;border:1px solid var(--line);border-radius:6px;font-size:11px;color:var(--muted);background:var(--panel)}
  .editor-interface-badge{display:inline-block;margin-left:5px;padding:2px 5px;border-radius:5px;background:var(--panel);color:var(--muted);font-size:9px;font-weight:500}
  .editor-interface-section{border:1px solid var(--line);border-radius:10px;background:var(--panel);margin-top:16px;overflow:hidden}
  .editor-interface-section>p{margin:10px 12px;color:var(--muted);font-size:11px;line-height:1.6}
  .editor-interface-output,.editor-interface-binding{display:grid;grid-template-columns:auto minmax(0,1fr) minmax(190px,290px);align-items:center;gap:10px;padding:10px 12px;border-top:1px solid var(--line)}
  .editor-interface-output input[type="checkbox"]{width:16px;height:16px;accent-color:var(--accent)}
  .editor-interface-binding{grid-template-columns:minmax(0,1fr) minmax(220px,340px);align-items:start}
  .editor-interface-binding-main{min-width:0;font-size:12px;font-weight:600;overflow-wrap:anywhere}
  .editor-interface-binding-meta{display:block;margin-top:4px;color:var(--muted);font-size:10px;font-weight:400;line-height:1.5}
  .editor-interface-binding select{width:100%;min-height:34px;padding:5px 8px;border:1px solid var(--line);border-radius:6px;background:var(--panel);color:var(--muted);font-size:11px}
  .editor-interface-empty{padding:14px 12px;color:var(--muted);font-size:12px}.editor-interface-required{color:var(--muted)}
  .editor-interface-conflict-preview{display:block;color:var(--muted);font-size:10px;line-height:1.45;overflow-wrap:anywhere;margin-top:4px}
  .editor-interface-conflict select{grid-column:1/-1}.editor-interface-conflict{grid-template-columns:minmax(0,1fr) minmax(200px,310px)}
  @media(max-width:720px){.editor-interface-layout{min-height:calc(100dvh - 28px)}.editor-interface-header,.editor-interface-footer{padding:12px}
    .editor-interface-body{padding:12px}.editor-interface-toolbar{grid-template-columns:1fr}.editor-interface-tabs{justify-content:flex-start}
    .editor-interface-field{grid-template-columns:auto minmax(0,1fr)}.editor-interface-field-name{grid-column:2}
    .editor-interface-output{grid-template-columns:auto minmax(0,1fr)}.editor-interface-output .editor-interface-field-meta{grid-column:2}
    .editor-interface-binding,.editor-interface-conflict{grid-template-columns:1fr}.editor-interface-binding select{grid-column:1}
    .editor-interface-status{max-width:50vw}.editor-interface-header h2{font-size:16px}}
`;

function openPanel({ title, description, confirmLabel, render, canConfirm, value }) {
  if (typeof document === 'undefined' || !document.body) return Promise.resolve(null);
  return new Promise(resolve => {
    const dialog = element('dialog', '', 'editor-interface-dialog');
    const style = element('style', PANEL_STYLE);
    const layout = element('div', '', 'editor-interface-layout');
    const header = element('header', '', 'editor-interface-header');
    const copy = element('div', '', 'editor-interface-header-copy');
    const heading = element('h2', title);
    const subheading = element('p', description);
    const close = element('button', '×', 'close-button editor-interface-close');
    close.type = 'button'; close.setAttribute('aria-label', '关闭');
    copy.append(heading, subheading); header.append(copy, close);
    const body = element('div', '', 'editor-interface-body');
    const footer = element('footer', '', 'editor-interface-footer');
    const status = element('p', '', 'editor-interface-status'); status.setAttribute('role', 'status');
    const actions = element('div', '', 'editor-interface-actions');
    const cancel = element('button', '取消', 'button quiet'); cancel.type = 'button';
    const confirm = element('button', confirmLabel, 'button primary'); confirm.type = 'button';
    actions.append(cancel, confirm); footer.append(status, actions);
    layout.append(header, body, footer); dialog.append(style, layout);
    let finished = false;
    const finish = result => {
      if (finished) return;
      finished = true;
      dialog.removeEventListener('cancel', onCancel);
      dialog.close?.(); dialog.remove(); resolve(result);
    };
    const onCancel = event => { event.preventDefault(); finish(null); };
    const setStatus = (message, error = false) => {
      status.textContent = message || '';
      status.dataset.error = String(error);
    };
    const updateConfirm = () => { confirm.disabled = !canConfirm(); };
    dialog.addEventListener('cancel', onCancel);
    dialog.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); finish(null); }
    });
    close.addEventListener('click', () => finish(null));
    cancel.addEventListener('click', () => finish(null));
    confirm.addEventListener('click', () => {
      if (!canConfirm()) return;
      finish(value());
    });
    document.body.append(dialog);
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
    render({ body, status: setStatus, updateConfirm });
    updateConfirm();
    close.focus?.();
  });
}

function idOptionText(item, id, labelKey = 'label') {
  const label = String(item?.[labelKey] ?? id);
  const mediaType = item?.mediaType ? ` · ${item.mediaType}` : '';
  return `${label} · ${id}${mediaType}`;
}

function appendPageControls(container, page, name, onPage) {
  if (page.pages <= 1) return;
  const controls = element('nav', '', 'editor-interface-actions');
  controls.setAttribute('aria-label', `${name}分页`);
  const previous = element('button', `${name}上一页`, 'button quiet'); previous.type = 'button'; previous.disabled = page.page === 0;
  const next = element('button', `${name}下一页`, 'button quiet'); next.type = 'button'; next.disabled = page.page === page.pages - 1;
  previous.addEventListener('click', () => onPage(page.page - 1));
  next.addEventListener('click', () => onPage(page.page + 1));
  controls.append(previous, element('span', `${page.page + 1}/${page.pages} 页 · ${page.total} 项`), next);
  container.append(controls);
}

function appendRebindingRows({
  container, title, note, rows, kind, choices, allCandidates, selectedIds, onTarget, viewState, rerender,
}) {
  if (!rows.length) return;
  const section = element('section', '', 'editor-interface-section');
  section.append(element('h3', title), element('p', note));
  const rowPage = interfacePage(rows, viewState.page);
  viewState.page = rowPage.page;
  appendPageControls(section, rowPage, title, page => { viewState.page = page; rerender(); });
  for (const row of rowPage.items) {
    const item = element('div', '', 'editor-interface-binding');
    const main = element('div', '', 'editor-interface-binding-main');
    main.append(element('span', row.label || row.id));
    const details = [];
    if (row.type || row.mediaType) details.push(`类型：${row.type ?? row.mediaType}`);
    details.push(row.connected ? `关联 ${row.connected} 条连线` :
      kind === 'field' ? '没有画布连线，仍需确认旧字段的绑定去向' : '当前无连线');
    if (kind === 'field' && row.reason === 'removed') details.push('字段已移除');
    if (kind === 'field' && row.reason === 'type_changed') details.push('字段类型已变化');
    if (row.reason === 'not_exposed') details.push('当前未暴露');
    if (row.reason === 'node_replaced') details.push('同编号内部节点已更换类型，须明确确认新绑定');
    if (kind === 'output' && row.reason === 'type_changed') details.push('输出媒体类型已变化');
    if (kind === 'output' && row.reason === 'removed') details.push('输出已移除');
    main.append(element('span', details.join(' · '), 'editor-interface-binding-meta'));
    if (row.valueSummary) main.append(element('span', row.valueSummary, 'editor-interface-binding-meta'));
    const select = element('select');
    select.setAttribute('aria-label', `${row.label || row.id} 的${kind === 'field' ? '字段' : '输出'}连线处理方式`);
    const blank = element('option', '请选择替代接口或解除绑定'); blank.value = ''; select.append(blank);
    const candidates = (row.candidates || allCandidates).filter(candidate =>
      (kind === 'field' ? fieldId(candidate) : outputId(candidate)) !== row.id || kind === 'output' && row.reason === 'node_replaced');
    const control = element('div');
    let candidateView = viewState.targets.get(row.id);
    if (!candidateView) { candidateView = { page: 0, query: '' }; viewState.targets.set(row.id, candidateView); }
    const search = element('input', '', 'editor-interface-search'); search.type = 'search'; search.value = candidateView.query;
    search.placeholder = '搜索重绑目标名称、ID、节点…';
    search.setAttribute('aria-label', `${row.label || row.id} 搜索重绑目标`);
    const targetPageArea = element('div');
    const renderTargets = () => {
      select.replaceChildren(blank);
      const page = interfacePage(interfaceSearch(candidates, candidateView.query), candidateView.page);
      candidateView.page = page.page;
      const displayed = [...page.items];
      const chosen = choices.get(row.id);
      if (chosen != null && !displayed.some(candidate => (kind === 'field' ? fieldId(candidate) : outputId(candidate)) === chosen)) {
        const retained = candidates.find(candidate => (kind === 'field' ? fieldId(candidate) : outputId(candidate)) === chosen);
        if (retained) displayed.unshift(retained);
      }
      for (const candidate of displayed) {
        const id = kind === 'field' ? fieldId(candidate) : outputId(candidate);
        const option = element('option', idOptionText(candidate, id)); option.value = JSON.stringify(id); select.append(option);
      }
      const disconnect = element('option', kind === 'field' ? '解除旧字段绑定' : '解除输出绑定（断开连线）');
      disconnect.value = 'null'; select.append(disconnect);
      select.value = choices.has(row.id) ? JSON.stringify(choices.get(row.id)) : '';
      targetPageArea.replaceChildren();
      appendPageControls(targetPageArea, page, `${row.label || row.id} 目标`, number => { candidateView.page = number; renderTargets(); });
    };
    search.addEventListener('input', () => { candidateView.query = search.value; candidateView.page = 0; renderTargets(); });
    control.append(search, select, targetPageArea); renderTargets();
    select.addEventListener('change', () => {
      if (!select.value) { choices.delete(row.id); onTarget(null, row); return; }
      const targetId = JSON.parse(select.value);
      choices.set(row.id, targetId === null ? FIELD_DISCONNECT : targetId);
      onTarget(targetId, row);
    });
    item.append(main, control); section.append(item);
  }
  container.append(section);
}

function mappingSummary(previousValues, previousBaseline, id) {
  if (!hasKey(previousValues, id) || !hasKey(previousBaseline, id)) return '';
  const outer = getKey(previousValues, id), baseline = getKey(previousBaseline, id);
  if (sameJsonValue(outer, baseline)) return '';
  return `上次外层值：${shortValuePreview(outer, 46)} · 内部基线：${shortValuePreview(baseline, 46)}`;
}

export function editorInputTargetsUnique(connections, choices) {
  const mapping = choices instanceof Map ? choices : new Map(Object.entries(choices || {}));
  const mapped = [...mapping.values()].filter(value => value !== null);
  if (new Set(mapped).size !== mapped.length) return false;
  const targets = (connections || []).filter(item => item.direction === 'input' && item.fieldId)
    .map(item => mapping.has(item.fieldId) ? mapping.get(item.fieldId) : item.fieldId)
    .filter(value => value !== null);
  return new Set(targets).size === targets.length;
}

/** Automatic compilation uses the same defaults and safety gates as the review panel. */
export function autoEditorInterfaceSelection({
  fields = [], outputs = [], previousFields = [], previousValues = {}, previousBaseline = {},
  selectedOutputs = [], connections = [], replaced_nodes: replacedNodes = {},
} = {}) {
  const candidates = (Array.isArray(fields) ? fields : []).filter(field => field && fieldId(field));
  const outputCandidates = (Array.isArray(outputs) ? outputs : []).filter(output => output && outputId(output));
  if (candidates.length > EDITOR_INTERFACE_CANDIDATE_LIMIT ||
      new Set(candidates.map(fieldId)).size !== candidates.length ||
      new Set(outputCandidates.map(outputId)).size !== outputCandidates.length) return null;
  const selectedFieldIds = initialEditorFieldIds(candidates, previousFields, previousValues, previousBaseline);
  const selectedOutputIds = initialEditorOutputIds(outputCandidates, selectedOutputs);
  if (selectedFieldIds.length > EDITOR_INTERFACE_FIELD_LIMIT || !selectedOutputIds.length ||
      selectedOutputIds.length > EDITOR_INTERFACE_OUTPUT_LIMIT ||
      !editorInputTargetsUnique(connections, {})) return null;
  const { inputRebindings, outputRebindings } = deriveEditorRebindings({
    fields: candidates, previousFields, selectedFieldIds, outputs: outputCandidates,
    selectedOutputIds, selectedOutputs, connections, replaced_nodes: replacedNodes,
  });
  if (inputRebindings.length || outputRebindings.length) return null;
  const selected = new Set(selectedFieldIds);
  const retained = new Map(previousFields.map(item => [previousFieldId(item), item]));
  return {
    fields: candidates.filter(field => selected.has(fieldId(field))).map(field => retainedField(field, retained)),
    output_nodes: selectedOutputIds, rebindings: {}, output_rebindings: {},
  };
}

/** Open a review panel. It never performs a fetch, edits the graph, or submits a job. */
export async function chooseEditorInterface({
  fields, outputs, previousFields = [], previousValues = {}, previousBaseline = {},
  selectedOutputs = [], connections = [], opaque_inputs: opaqueInputs = [], requires_native_compile: requiresNativeCompile = false,
  replaced_nodes: replacedNodes = {},
} = {}) {
  const retained = new Map(previousFields.map(item => [previousFieldId(item), item]));
  const candidates = (Array.isArray(fields) ? fields : []).filter(field => field && fieldId(field))
    .map(field => retainedField(field, retained));
  const outputCandidates = (Array.isArray(outputs) ? outputs : []).filter(output => output && outputId(output));
  if (typeof document === 'undefined' || !document.body) return null;

  const selectedFieldIds = new Set(initialEditorFieldIds(candidates, previousFields, previousValues, previousBaseline));
  const candidatesById = new Map(candidates.map(field => [fieldId(field), field]));
  const selectedOutputIds = new Set(initialEditorOutputIds(outputCandidates, selectedOutputs));
  const requiredFieldIds = new Set(candidates.filter(isRequiredEditorMediaField).map(fieldId));
  const labels = new Map();
  const presentations = new Map(candidates.map(field => [fieldId(field), field.presentation]));
  const inputChoices = new Map();
  const outputChoices = new Map();
  let groupFilter = '全部';
  let searchText = '';
  let fieldPage = 0, outputPage = 0, outputSearch = '';
  const bindingViews = { field: { page: 0, targets: new Map() }, output: { page: 0, targets: new Map() } };
  let transientError = '';

  const getBindings = () => deriveEditorRebindings({
    fields: candidates, previousFields, selectedFieldIds: [...selectedFieldIds],
    outputs: outputCandidates, selectedOutputIds: [...selectedOutputIds], selectedOutputs, connections, replaced_nodes: replacedNodes,
  });
  const hasValidBindings = (rows, choices, selected, kind) => rows.every(row => {
    if (!choices.has(row.id)) return false;
    const target = choices.get(row.id);
    if (target === null) return true;
    return selected.has(target) && (kind === 'output' || target !== row.id &&
      typeOf(row) && typeOf(row) === typeOf(candidatesById.get(target)));
  });
  const valid = () => {
    const { inputRebindings, outputRebindings } = getBindings();
    return candidates.length <= EDITOR_INTERFACE_CANDIDATE_LIMIT && selectedFieldIds.size <= EDITOR_INTERFACE_FIELD_LIMIT &&
      editorInputTargetsUnique(connections, inputChoices) &&
      [...requiredFieldIds].every(id => selectedFieldIds.has(id)) && selectedOutputIds.size >= 1 &&
      selectedOutputIds.size <= EDITOR_INTERFACE_OUTPUT_LIMIT &&
      hasValidBindings(inputRebindings, inputChoices, selectedFieldIds, 'field') &&
      hasValidBindings(outputRebindings, outputChoices, selectedOutputIds, 'output');
  };

  return openPanel({
    title: '配置外层接口',
    description: '勾选需要外露到侧栏的输入，再选择显示为画布端口或侧栏控件。可搜索和按分类查找；图像、视频、音频入口均可连线或上传。旧字段或连线受影响时须明确重绑或解除。',
    confirmLabel: '应用外层面板',
    canConfirm: valid,
    value: () => {
      const chosenFields = candidates.filter(field => selectedFieldIds.has(fieldId(field))).map(field => ({
        ...field, label: labels.has(fieldId(field)) ? labels.get(fieldId(field)) : field.label,
        presentation: presentations.get(fieldId(field)),
      }));
      const { inputRebindings, outputRebindings } = getBindings();
      return {
        fields: chosenFields,
        output_nodes: outputCandidates.map(outputId).filter(id => selectedOutputIds.has(id)),
        rebindings: Object.fromEntries(inputRebindings.map(row => [row.id, inputChoices.get(row.id)])),
        output_rebindings: Object.fromEntries(outputRebindings.map(row => [row.id, outputChoices.get(row.id)])),
      };
    },
    render({ body, status, updateConfirm }) {
      if (Array.isArray(opaqueInputs) && opaqueInputs.length) body.append(element('p',
        `${opaqueInputs.length} 个内部输入尚未取得当前节点的输入契约。原值与连线已保留；请在当前引擎的原生工作流中重新编译。额外连线可编辑其上游已声明输入，未知纯值不会自动外露为可写控件。`,
        'editor-interface-note'));
      else if (requiresNativeCompile) body.append(element('p', '此工作流的动态输入需要在当前引擎中重新打开、编译并应用。已保存的图与参数仍保留。', 'editor-interface-note'));
      const toolbar = element('div', '', 'editor-interface-toolbar');
      const search = element('input', '', 'editor-interface-search');
      search.type = 'search'; search.placeholder = '搜索参数名、节点、类型…';
      search.setAttribute('aria-label', '搜索参数');
      const tabs = element('nav', '', 'editor-interface-tabs'); tabs.setAttribute('aria-label', '参数分类');
      const fieldCount = element('p', '', 'editor-interface-count');
      const fieldArea = element('div');
      const outputArea = element('div');
      const outputSearchInput = element('input', '', 'editor-interface-search');
      outputSearchInput.type = 'search'; outputSearchInput.placeholder = '搜索输出名称、ID…';
      outputSearchInput.setAttribute('aria-label', '搜索输出分支');
      const bindingArea = element('div');
      const setTabs = () => {
        tabs.replaceChildren();
        for (const group of ['全部', ...EDITOR_INTERFACE_GROUPS]) {
          const button = element('button', group, 'editor-interface-tab'); button.type = 'button';
          button.setAttribute('aria-pressed', String(groupFilter === group));
          button.addEventListener('click', () => { groupFilter = group; fieldPage = 0; setTabs(); renderFields(); });
          tabs.append(button);
        }
      };
      const showStatus = () => {
        const { inputRebindings, outputRebindings } = getBindings();
        const unresolvedInputs = inputRebindings.filter(row => !inputChoices.has(row.id)).length;
        const unresolvedOutputs = outputRebindings.filter(row => !outputChoices.has(row.id)).length;
        const requiredMissing = [...requiredFieldIds].filter(id => !selectedFieldIds.has(id)).length;
        const invalidInputTargets = inputRebindings.some(row => inputChoices.has(row.id) &&
          inputChoices.get(row.id) !== null && !selectedFieldIds.has(inputChoices.get(row.id)));
        const invalidOutputTargets = outputRebindings.some(row => outputChoices.has(row.id) &&
          outputChoices.get(row.id) !== null && !selectedOutputIds.has(outputChoices.get(row.id)));
        const messages = [];
        if (candidates.length > EDITOR_INTERFACE_CANDIDATE_LIMIT) messages.push(`候选参数超过 ${EDITOR_INTERFACE_CANDIDATE_LIMIT} 个，请精简内部工作流后重新编译。`);
        if (selectedFieldIds.size > EDITOR_INTERFACE_FIELD_LIMIT) messages.push(`最多暴露 ${EDITOR_INTERFACE_FIELD_LIMIT} 个参数。`);
        if (requiredMissing) messages.push('所有 image/video/audio 媒体参数都必须保留。');
        if (!selectedOutputIds.size) messages.push('至少选择一个输出分支。');
        if (selectedOutputIds.size > EDITOR_INTERFACE_OUTPUT_LIMIT) messages.push(`最多选择 ${EDITOR_INTERFACE_OUTPUT_LIMIT} 个输出分支，请取消其他输出。`);
        if (unresolvedInputs || unresolvedOutputs) messages.push(`请处理 ${unresolvedInputs + unresolvedOutputs} 项接口绑定。`);
        if (invalidInputTargets || invalidOutputTargets) messages.push('重绑定目标也必须选入外层面板。');
        if (!editorInputTargetsUnique(connections, inputChoices)) messages.push('多个输入不能重绑到同一字段，请改选或解除其中一条。');
        if (transientError) messages.push(transientError);
        status(messages.join(' ') || `${selectedFieldIds.size}/${EDITOR_INTERFACE_FIELD_LIMIT} 个参数已选；${selectedOutputIds.size} 个输出已选。`, !!transientError);
        updateConfirm();
      };
      const matchingFields = () => {
        const matches = new Set(interfaceSearch(candidates.map(field => ({ ...field,
          label: labels.get(fieldId(field)) ?? field.label, group: editorFieldGroup(field) })), searchText).map(fieldId));
        return candidates.filter(field => matches.has(fieldId(field)) &&
          (groupFilter === '全部' || editorFieldGroup(field) === groupFilter));
      };
      const renderFields = () => {
        fieldArea.replaceChildren();
        const matching = matchingFields();
        const page = interfacePage(matching, fieldPage); fieldPage = page.page;
        const visible = page.items;
        appendPageControls(fieldArea, page, '参数', number => { fieldPage = number; renderFields(); });
        if (!visible.length) fieldArea.append(element('p', '没有匹配的参数。', 'editor-interface-empty'));
        for (const group of EDITOR_INTERFACE_GROUPS) {
          const groupItems = visible.filter(field => editorFieldGroup(field) === group);
          if (!groupItems.length) continue;
          const section = element('section', '', 'editor-interface-group');
          section.append(element('h3', `${group} · ${groupItems.length}`));
          for (const field of groupItems) {
            const id = fieldId(field), row = element('div', '', 'editor-interface-field');
            const checkbox = element('input'); checkbox.type = 'checkbox'; checkbox.checked = selectedFieldIds.has(id);
            checkbox.disabled = requiredFieldIds.has(id); checkbox.setAttribute('aria-label', `暴露参数 ${field.label || field.input || id}`);
            checkbox.addEventListener('change', () => {
              transientError = '';
              if (checkbox.checked && !selectedFieldIds.has(id) && selectedFieldIds.size >= EDITOR_INTERFACE_FIELD_LIMIT) {
                checkbox.checked = false; transientError = `最多暴露 ${EDITOR_INTERFACE_FIELD_LIMIT} 个参数，请先取消其他参数。`;
              } else if (checkbox.checked) selectedFieldIds.add(id);
              else selectedFieldIds.delete(id);
              renderFields(); renderOutputs(); renderBindings(); showStatus();
            });
            const info = element('div', '', 'editor-interface-field-main');
            const title = element('div', '', 'editor-interface-field-title');
            title.append(element('span', field.label || field.input || id));
            if (field.recommended === true) title.append(element('span', '推荐', 'editor-interface-badge'));
            if (requiredFieldIds.has(id)) title.append(element('span', '必选媒体', 'editor-interface-badge editor-interface-required'));
            const metaParts = [`节点 ${field.node_id ?? '—'}`, String(field.input ?? id), String(field.type ?? '未知类型')];
            info.append(title, element('div', metaParts.join(' · '), 'editor-interface-field-meta'));
            const name = element('input', '', 'editor-interface-field-name'); name.type = 'text';
            name.maxLength = 100; name.value = labels.get(id) ?? String(field.label ?? field.input ?? id);
            name.setAttribute('aria-label', `外层显示名称：${field.label || field.input || id}`);
            name.addEventListener('input', () => { labels.set(id, name.value.trim() || String(field.label ?? field.input ?? id)); });
            const settings = element('div', '', 'editor-interface-field-settings');
            const presentation = element('select', '', 'editor-interface-field-name');
            presentation.setAttribute('aria-label', `显示方式：${field.label || field.input || id}`);
            const control = element('option', '侧栏控件'); control.value = 'control'; presentation.append(control);
            if (editorFieldSupportsPort(field)) {
              const port = element('option', '画布端口 + 侧栏控件'); port.value = 'port'; presentation.append(port);
            }
            presentation.value = presentations.get(id);
            presentation.disabled = !selectedFieldIds.has(id) || !editorFieldSupportsPort(field);
            presentation.addEventListener('change', () => {
              presentations.set(id, editorFieldSupportsPort(field) && presentation.value === 'port' ? 'port' : 'control');
            });
            settings.append(name, presentation);
            row.append(checkbox, info, settings); section.append(row);
          }
          fieldArea.append(section);
        }
        fieldCount.textContent = `已选 ${selectedFieldIds.size}/${EDITOR_INTERFACE_FIELD_LIMIT} 个参数 · 筛选 ${matching.length}/${candidates.length} 项 · 默认推荐最多 ${DEFAULT_INTERFACE_FIELDS} 项（媒体全保留） · image/video/audio 必须暴露 · 已连接端口仍保留连线`;
      };
      const renderOutputs = () => {
        outputArea.replaceChildren();
        const section = element('section', '', 'editor-interface-section');
        section.append(element('h3', `输出分支 · ${selectedOutputIds.size} 个已选`),
          element('p', '至少保留一个输出。已连线的输出如被取消，需明确改接其他输出或解除连线。'));
        if (!outputCandidates.length) section.append(element('div', '当前工作流没有可用输出节点。', 'editor-interface-empty'));
        const page = interfacePage(interfaceSearch(outputCandidates, outputSearch), outputPage); outputPage = page.page;
        appendPageControls(section, page, '输出', number => { outputPage = number; renderOutputs(); });
        for (const output of page.items) {
          const id = outputId(output), row = element('label', '', 'editor-interface-output');
          const checkbox = element('input'); checkbox.type = 'checkbox'; checkbox.checked = selectedOutputIds.has(id);
          checkbox.setAttribute('aria-label', `选择输出 ${output.label || id}`);
          checkbox.addEventListener('change', () => {
            if (checkbox.checked) selectedOutputIds.add(id); else selectedOutputIds.delete(id);
            renderOutputs(); renderBindings(); showStatus();
          });
          const title = element('span', output.label || id);
          const meta = element('span', `${output.mediaType || '未知媒体'} · ${id}`, 'editor-interface-field-meta');
          row.append(checkbox, title, meta); section.append(row);
        }
        outputArea.append(section);
      };
      const activateTarget = (targetId, kind) => {
        transientError = '';
        if (targetId === null || targetId === undefined) { showStatus(); return; }
        if (kind === 'field' && !selectedFieldIds.has(targetId)) {
          if (selectedFieldIds.size >= EDITOR_INTERFACE_FIELD_LIMIT) {
            transientError = `已达到 ${EDITOR_INTERFACE_FIELD_LIMIT} 个参数上限；先取消一个，再选择这个重绑定目标。`;
          } else selectedFieldIds.add(targetId);
        }
        if (kind === 'output') selectedOutputIds.add(targetId);
        renderFields(); renderOutputs(); renderBindings(); showStatus();
      };
      const renderBindings = () => {
        bindingArea.replaceChildren();
        const { inputRebindings, outputRebindings } = getBindings();
        for (const row of inputRebindings) row.valueSummary = mappingSummary(previousValues, previousBaseline, row.id);
        appendRebindingRows({
          container: bindingArea, title: '外层输入绑定处理',
          note: '旧字段已删除、类型变化或不再暴露。每项须明确选兼容字段或解除绑定。',
          rows: inputRebindings, kind: 'field', choices: inputChoices, allCandidates: candidates,
          selectedIds: selectedFieldIds, onTarget: target => activateTarget(target, 'field'),
          viewState: bindingViews.field, rerender: renderBindings,
        });
        appendRebindingRows({
          container: bindingArea, title: '输出连线处理',
          note: '这些输出仍有外层连线，但已取消选择或从内部工作流移除。请选择新输出或明确解除。',
          rows: outputRebindings, kind: 'output', choices: outputChoices, allCandidates: outputCandidates,
          selectedIds: selectedOutputIds, onTarget: target => activateTarget(target, 'output'),
          viewState: bindingViews.output, rerender: renderBindings,
        });
      };
      const bulk = element('div', '', 'editor-interface-actions');
      for (const [select, label] of [[true, '勾选筛选结果'], [false, '取消筛选结果']]) {
        const action = element('button', label, 'button quiet'); action.type = 'button';
        action.addEventListener('click', () => {
          transientError = '';
          for (const field of matchingFields()) {
            const id = fieldId(field);
            if (select) selectedFieldIds.add(id);
            else if (!requiredFieldIds.has(id)) selectedFieldIds.delete(id);
          }
          renderFields(); renderBindings(); showStatus();
        }); bulk.append(action);
      }
      toolbar.append(search, tabs); body.append(toolbar, fieldCount, bulk, fieldArea);
      if (outputCandidates.length > 64) body.append(outputSearchInput);
      body.append(outputArea, bindingArea);
      outputSearchInput.addEventListener('input', () => { outputSearch = outputSearchInput.value; outputPage = 0; renderOutputs(); });
      search.addEventListener('input', () => { searchText = search.value; fieldPage = 0; renderFields(); });
      setTabs(); renderFields(); renderOutputs(); renderBindings(); showStatus();
    },
  });
}

/** Resolve outside edits against edits made inside the native workflow editor. */
export async function resolveEditorConflicts(conflicts) {
  const items = Array.isArray(conflicts) ? conflicts : [];
  if (!items.length) return {};
  if (typeof document === 'undefined' || !document.body) return null;
  const choices = new Map();
  const rawKeys = items.map((item, index) => String(item?.id ?? item?.index ?? index));
  const keyCounts = new Map();
  for (const key of rawKeys) keyCounts.set(key, (keyCounts.get(key) || 0) + 1);
  const usedKeys = new Set();
  const keys = rawKeys.map((key, index) => {
    let unique = keyCounts.get(key) === 1 ? key : `#${index}`;
    while (usedKeys.has(unique)) unique = `#${index}-${usedKeys.size}`;
    usedKeys.add(unique);
    return unique;
  });
  return openPanel({
    title: '处理参数修改冲突',
    description: '参数两边都被修改，或原外层值不再符合新接口。逐项确认；也可以取消后返回修改。提示词仅显示短预览。',
    confirmLabel: '应用所选修改',
    canConfirm: () => items.every((_item, index) => choices.has(keys[index])),
    value: () => Object.fromEntries(keys.map(key => [key, choices.get(key)])),
    render({ body, status, updateConfirm }) {
      const section = element('section', '', 'editor-interface-section editor-interface-conflict-list');
      let conflictPage = 0;
      const renderConflicts = () => {
      section.replaceChildren(element('h3', `需要决定 · ${items.length} 项 · 已决定 ${choices.size} 项`));
      const page = interfacePage(items.map((conflict, index) => ({ conflict, index })), conflictPage);
      conflictPage = page.page;
      appendPageControls(section, page, '冲突', number => { conflictPage = number; renderConflicts(); });
      for (const { index, conflict } of page.items) {
        const key = keys[index];
        const row = element('div', '', 'editor-interface-binding editor-interface-conflict');
        const main = element('div', '', 'editor-interface-binding-main');
        main.append(element('span', conflict?.label ?? conflict?.fieldLabel ?? key));
        const pickValue = names => {
          for (const name of names) if (conflict && Object.hasOwn(conflict, name)) return conflict[name];
          return undefined;
        };
        const outer = pickValue(['outerValue', 'outer_value', 'outer']);
        const inner = pickValue(['innerValue', 'inner_value', 'inner']);
        main.append(element('span', `外层值：${shortValuePreview(outer)}`, 'editor-interface-conflict-preview'));
        main.append(element('span', `内部值：${shortValuePreview(inner)}`, 'editor-interface-conflict-preview'));
        if (conflict?.reason) main.append(element('span', `原外层值不可用：${conflict.reason}`, 'editor-interface-warning'));
        const select = element('select');
        select.setAttribute('aria-label', `${conflict?.label ?? key} 冲突处理方式`);
        const blank = element('option', '请选择保留哪一方'); blank.value = ''; select.append(blank);
        for (const [value, label] of [['outer', '采用外层值'], ['inner', '采用内部值']]) {
          if (Array.isArray(conflict?.allowed) && !conflict.allowed.includes(value)) continue;
          const option = element('option', label); option.value = value; select.append(option);
        }
        select.value = choices.get(key) || '';
        select.addEventListener('change', () => {
          if (select.value === 'outer' || select.value === 'inner') choices.set(key, select.value);
          else choices.delete(key);
          status(items.every((_item, itemIndex) => choices.has(keys[itemIndex])) ? '' : '请为每项冲突选择保留的一方。');
          updateConfirm();
        });
        row.append(main, select); section.append(row);
      }
      }; renderConflicts();
      body.append(section);
      status('请为每项冲突选择保留的一方。');
      updateConfirm();
    },
  });
}

