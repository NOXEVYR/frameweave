"""PrismCanvas 棱光, with the compatible FrameWeave data and API identity."""

__version__ = "0.9.2"
